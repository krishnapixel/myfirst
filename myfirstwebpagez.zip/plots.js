let data = [{
 x: [1930, 1940, 1950, 1960],
 y: [573076, 575901, 580132, 532759]
}];
Plotly.newPlot('myPlot', data);

let data = [{
 x: [1930, 1940, 1950, 1960],
 y: [573076, 575901, 580132, 532759],
 name: "Buffalo Population"
}];
let layout = {
 "title": "Buffalo Population",
 xaxis: {
 "title": "year"
 },
 yaxis:{
 "title": "population"
 }
}
Plotly.newPlot('myPlot', data, layout);